package net.faintedge.spiral.core;

import org.newdawn.slick.Graphics;

public interface Renderable {

  void render(Graphics g);

}