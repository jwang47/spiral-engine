package net.faintedge.spiral.core;


public class Camera {
  
  private Vector2 position;
  
  public Camera() {
    position = new Vector2();
  }

  public Vector2 getPosition() {
    return position;
  }
  
}
