package net.faintedge.spiral.core.component;

import com.artemis.Component;

public class Move extends Component {

  
  
}
