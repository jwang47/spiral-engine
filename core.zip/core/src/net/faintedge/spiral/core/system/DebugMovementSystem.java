package net.faintedge.spiral.core.system;

public class DebugMovementSystem {

}
