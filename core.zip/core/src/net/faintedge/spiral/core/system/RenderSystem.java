package net.faintedge.spiral.core.system;

import net.faintedge.spiral.core.Vector2;
import net.faintedge.spiral.core.component.Render;
import net.faintedge.spiral.core.component.Transform;

import org.newdawn.slick.Graphics;

import com.artemis.ComponentMapper;
import com.artemis.Entity;
import com.artemis.EntityProcessingSystem;

public class RenderSystem extends EntityProcessingSystem {
  
  private ComponentMapper<Transform> transformMapper;
  private ComponentMapper<Render> renderMapper;
  
  private Graphics graphics;

  public RenderSystem() {
    super(Transform.class, Render.class);
  }

  @Override
  protected void initialize() {
    transformMapper = new ComponentMapper<Transform>(Transform.class, world);
    renderMapper = new ComponentMapper<Render>(Render.class, world);
  }

  @Override
  protected void process(Entity e) {
    Transform transform = transformMapper.get(e);
    Render render = renderMapper.get(e);
    
    Vector2 translation = transform.getTranslation();
    float rotation = transform.getRotation();

    graphics.rotate(translation.getX(), translation.getY(), rotation);
    graphics.translate(translation.getX(), translation.getY());
    render.getRenderable().render(graphics);
    graphics.translate(-translation.getX(), -translation.getY());
    graphics.rotate(translation.getX(), translation.getY(), -rotation);
  }

  public Graphics getGraphics() {
    return graphics;
  }

  public void setGraphics(Graphics graphics) {
    this.graphics = graphics;
  }

}
